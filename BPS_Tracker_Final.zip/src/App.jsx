import React from 'react';
import MainApp from './mainApp';
import './index.css';
export default function App(){return <MainApp/>;}